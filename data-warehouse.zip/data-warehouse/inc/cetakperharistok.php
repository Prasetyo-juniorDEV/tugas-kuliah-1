<?php include "koneksi.php" ;
include "tglindo.php" ;
$tgl = date('d M Y');
?>
<body onLoad="javascript:print()">
    <style type="text/css">
        <!--
        .style3 {
            font-size: 12px
        }
        -->
        .style5
        {
        font-size:
        24px
        }
    </style>
    <div class="panel-heading">
        <table width="100%">
            <br> Tanggal : <?php echo " $tgl";?>
        </div>
    <tr>
        <td>
            <div align="center">
                Laporan Data Barang<br>PT. AMIA BATUSANGKAR
        </td>
    </tr>
    </table>
    </div>
    <table id='theList' border=1 width='100%' class='table table-bordered table-striped'>
        <tr>
            <th>No.</th>
            <th>Kode Barang</th>
            <th>Nama Barang</th>
            <th>Satuan</th>
            <th>Harga Beli</th>
            <th>Harga Jual</th>
            <th>Stok Awal</th>
            <th>Stok Terjual</th>
            <th>Stok Sisa</th>
            <th>Tgl Barang Masuk</th>
        </tr>
        <?php
$sql = mysqli_query($koneksi,"select * from tb_barang where tanggal like '$_POST[bulan]%' ");
$no=1;
while($r = mysqli_fetch_array($sql)){
if($r[aktif]==1){
$status="Online";
}else{
$status="Offline";
}
?>
        <tr>
            <td class='td' align='center'><span class="style3">
                    <?echo$no;?></span></td>
            <td><?php echo $r['kode_barang']; ?></td>
            <td><?php echo $r['nama_barang']; ?></td>
            <td><?php echo $r['satuan']; ?></td>
            <td><?php echo number_format($r['harga_beli'], 2, ".", ","); ?></td>
            <td><?php echo number_format($r['harga_jual'], 2, ".", ","); ?></td>
            <td><?php echo $r['stok_awal']; ?></td>
            <td><?php echo $r['stok_terjual']; ?></td>
            <td><?php echo $r['stok_sisa']; ?></td>
            <td><?php echo $r['tanggal']; ?></td>
        </tr>
        <?
$no++;}?>
    </table>
    <br>
    <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
        <tr>
            <td width="63%" bgcolor="#FFFFFF">
                <p align="center"><br />
            </td>
            <td width="37%" bgcolor="#FFFFFF">
                <div align="center"> <?php echo "Batusangkar, $tgl";?><br />
                    <br /><br />
                    <br /><br />H DARWIN<br />
                </div>
            </td>
        </tr>
    </table>
</body>