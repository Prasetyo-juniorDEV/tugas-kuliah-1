<?php
@session_start();
include "koneksi.php";
$user = @mysqli_real_escape_string($koneksi,$_POST['user']);
$pass = @mysqli_real_escape_string($koneksi,$_POST['pass']);
$sql = mysqli_query($koneksi,"SELECT * from tb_user where username = '$user' and password = md5('$pass')") or
die (mysqli_error($koneksi));
$cek = mysqli_num_rows($sql);
if($cek >= 1)
{
$data = mysqli_fetch_array($sql);
$id_user = $data['kode_user'];
if($data['level'] == "admin")
{
@$_SESSION['admin'] = $id_user;
?> <script>
window.location.href="index.php";
</script> <?php
}
else if($data['level'] == "kasir")
{
@$_SESSION['kasir'] = $id_user;
?> <script>
window.location.href="index.php";
</script> <?php
}
else if($data['level'] == "pimpinan")
{
@$_SESSION['pimpinan'] = $id_user;
?> <script>
window.location.href="index.php";
</script> <?php
}
}
else
{
?> <script>
$("#pesan").css({"background-color":"rgba(255,0,0,0.5)", "border-left":"5px solid#f00"}).html("Login gagal, mohon ulangi kembali");
$("#user").val('');
$("#pass").val('');
$("#user").focus();
</script> <?php
}
?>