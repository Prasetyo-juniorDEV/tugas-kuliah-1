<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "db_penjualan";
$koneksi=mysqli_connect($servername,$username,$password,$database);
?>