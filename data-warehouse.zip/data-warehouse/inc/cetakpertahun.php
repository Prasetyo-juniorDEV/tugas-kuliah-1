<?php include "koneksi.php" ;
include "tglindo.php" ;
$tgl = date('d M Y');
?>
<body onLoad="javascript:print()">
    <style type="text/css">
        <!--
        .style3 {
            font-size: 12px
        }
        -->
        .style5
        {
            font-size:
        24px
        }
    </style>
    <div class="panel-heading">
        <table width="100%">
            BATUSANGKAR <br> Tanggal : <?php echo " $tgl";?>
    </div>
    </div>
    <tr>
        <td>
            <div align="center">
                <div align="center">
                    Laporan Data Penjualan Barang<br>PT. AMIA
        </td>
    </tr>
    </table>
    <table id='theList' border=1 width='100%' class='table table-bordered table-striped'>
        <tr>
            <th>No.</th>
            <th>No Nota</th>
            <th>Tanggal Jual</th>
            <th>Pelanggan</th>
            <th>Kasir</th>
            <th>Sub Total</th>
            <th>Diskon Persen</th>
            <th>Diskon Harga</th>
            <th>Total Harga</th>
        </tr>
        <?php
$sql = mysqli_query($koneksi,"select * from tb_penjualan where tgl_jual like '$_POST[bulan]%' ");
$no=1;
while($r = mysqli_fetch_array($sql)){
if($r[aktif]==1){
$status="Online";
}else{
$status="Offline";
}
?>
        <tr>
            <td class='td' align='center'><span class="style3">
                    <?echo$no;?></span></td>
            <td><?php echo $r['no_nota']; ?></td>
        </tr>
        <td><?php echo $r['tgl_jual']; ?></td>
        <td><?php echo $r['pelanggan']; ?></td>
        <td><?php echo $r['kasir']; ?></td>
        <td>Rp. <?php echo number_format($r['sub_total'], 2, ".","");?></td>
        <td><?php echo $r['diskon_persen']." %";?></td>
        <td>Rp. <?php echo number_format($r['diskon_total'], 2, ".","");?></td>
        <td>Rp. <?php echo number_format($r['total_harga'], 2, ".","");?></td>
        <?
$no++;
$total+=$r['total_harga'];
}
?>
        <tr>
            <td colspan="8">
                <div align="right">Total Keseluruhan </div>
            </td>
            <td>Rp.<?php echo number_format($total, 2, ".", ","); ?> </td>
        </tr>
    </table>
    <br>
    <table width="100%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
        <tr>
            <td width="63%" bgcolor="#FFFFFF">
                <p align="center"><br />
            </td>
            <td width="37%" bgcolor="#FFFFFF">
                <div align="center"> <?php $tgl = date('d M Y');
echo "Batusangkar, $tgl";?><br />
                    <br/><br />
                    <br/><br /> H DARWIN<br/>
    </div>
    </td>
                </tr></table>