<?php
include "inc/koneksi.php";
$id_brg = @$_GET['id'];
$sql2 = mysqli_query($koneksi,"select * from tb_penjualan where no_nota = '$id_brg'") or die (mysqli_error($koneksi));
$data2 = mysqli_fetch_array($sql2);
?>
<body onLoad="javascript:print()">
<table width="416" border="1" align="center">
<tr>
<td colspan="2" bgcolor="#CCCCCC"><div align="center"><strong>Cetak Struk </strong></div></td>
</tr>
<tr>
<td width="114">No Nota</td>
<td width="286">: <?php echo $data2['no_nota']; ?></td>
</tr>
<tr>
<td>Tanggal Jual</td>
<td>: <?php echo $data2['tgl_jual']; ?></td>
</tr>
<tr>
<td>Pelanggan</td>
<td>: <?php echo $data2['pelanggan']; ?></td>
</tr>
<tr>
<td>Kasir</td>
<td>: <?php echo $data2['kasir']; ?></td>
</tr>
<tr>
<td>Sub Total</td>
<td>: Rp.<?php echo number_format($data2['sub_total'], 2, ".", ","); ?></td>
</tr>
<tr>
<td>Diskon % </td>
<td>: <?php echo number_format($data2['diskon_persen'], 2, ".", ","); ?></td>
</tr>
<tr>
<td>Diskon Harga</td>
<td>: Rp. <?php echo number_format($data2['diskon_total'], 2, ".", ","); ?></td>
</tr>
<tr>
<td>Total Harga </td>
<td>: Rp.<?php echo number_format($data2['total_harga'], 2, ".", ","); ?></td>
</tr>
</table>