<?php @session_start(); include "inc/koneksi.php"; ?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" href="img/favicon.png" />
    <link rel="stylesheet" href="style/style.css" />
    <link rel="stylesheet" href="style/jquery-ui.css" />
</head>

<body>
    <nav>
        <ul>
            <?php if(@$_SESSION['admin'] || @$_SESSION['pimpinan'] || @$_SESSION['kasir'])?>
            <li class="utama">
                <a href="./">Home</a>
                <ul>
                    <?php
if(@$_SESSION['admin']) {
$sesi = @$_SESSION['admin'];
} else if(@$_SESSION['kasir']) {
$sesi = @$_SESSION['kasir'];
} ?>
                </ul>
            </li>
            <?php
{ ?>
            <?php if(@$_SESSION['kasir']) {
            ?>
            <li><a href="?page=penjualan&action=view">Data Penjualan</a>
            </li>
            <ul>
                <li class="utama"><a href="">Transaksi</a>
            </ul>
            </li>
            </a></li>
            <li><a href="?page=penjualan&action=input">Penjualan</a></li>
            <li class="utama"><a href="">Laporan Stok</a>
                <ul>
                    <li><a href="?page=laporan_perhari_stok">Laporan Perhari </a></li>
                    <li><a href="?page=laporan_perbulan_stok">Laporan Perbulan</a></li>
                    <li><a href="?page=laporan_pertahun_stok">Laporan Pertahun</a></li>
                </ul>
            </li>
            <li class="utama"><a href="">Laporan Penjualan</a>
                <ul>
                    <li><a href="?page=laporan_perhari">Laporan Perhari</a></li>
                    <li><a href="?page=laporan_perbulan">Laporan Perbulan</a>
                    </li>
                    <li><a href="?page=laporan_pertahun">Laporan Pertahun</a>
                    </li>
            </li>
        </ul>
        <?php
        } ?>
        <?php
if(@$_SESSION['admin']) {
    ?>
        <li><a href="?page=petugas&action=view">Petugas</a></li>
        <li class="utama"><a href="">Data Master</a>
            <ul>
                <li><a href="?page=barang&action=view">Data Barang</a></li>
                <li><a href="?page=petugas&action=view"> Data petugas</a></li>
                <li><a href="?page=pimpinan&action=view"> Data Pimpinan</a></li>
                <li><a href="?page=penjualan&action=view">Data Penjualan</a>
                </li>
        </li>
        </ul>
        <li class="utama"><a href="">Laporan Stok</a>
            <ul>
                <li><a href="?page=laporan_perhari_stok">Laporan Perhari </a></li>
                <li><a href="?page=laporan_perbulan_stok">Laporan Perbulan</a></li>
                <li><a href="?page=laporan_pertahun_stok">Laporan Pertahun</a></li>
            </ul>
        </li>
        <li class="utama"><a href="">Laporan Penjualan</a>
            <ul>
                <li><a href="?page=laporan_perhari">Laporan Perhari</a></li>
                <li><a href="?page=laporan_perbulan">Laporan Perbulan</a>
                </li>
                <li><a href="?page=laporan_pertahun">Laporan Pertahun</a>
                </li>
        </li>
        </ul>
        <li class="utama"><a href="">Format</a>
            <ul>
                <li><a href="?page=visi">Halaman Utama</a></li>
            </ul>
        </li>
        <?php }?>
        <?php
        if(@$_SESSION['pimpinan']) {
            ?> <li class="utama"><a href="">Laporan Stok</a>
            <ul>
                <li><a href="?page=laporan_perhari_stok">Laporan Perhari </a></li>
                <li><a href="?page=laporan_perbulan_stok">Laporan Perbulan</a></li>
                <li><a href="?page=laporan_pertahun_stok">Laporan Pertahun</a></li>
            </ul>
        </li>
        <li class="utama"><a href="">Laporan Penjualan</a>
            <ul>
                <li><a href="?page=laporan_perhari">Laporan Perhari</a></li>
                <li><a href="?page=laporan_perbulan">Laporan Perbulan</a></li>
                <li><a href="?page=laporan_pertahun">Laporan Pertahun</a></li>
            </ul>
        </li>
        <?php
} ?>
        <li class="utama"><a href="#">Setting</a>
            <ul>
                <li><a href="?page=akun&id=<?php echo $sesi; ?>">Edit Akun</a></li>
                <li><a href="?page=logout">Keluar</a></li>
            </ul>
        </li>
        <?php 
        ?><li class="utama">
            <a href="?page=login">Silahkan login terlebih dahulu</a>
        </li>
        <?php } ?>
        </ul>
    </nav>
    <script src="inc/jquery.js"></script>
    <script src="inc/jquery-ui.js"></script>
    <script src="inc/jquery-number.js"></script>
    <script>
        $(function () {
            $(".datepicker").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat: 'dd-mm-yy',
                yearRange: '-25:+10'
            });
        });
    </script>
    <main>
        <?php
if(@$_GET['page'] == '') {
if(@$_SESSION['admin'] || @$_SESSION['pimpinan'] || @$_SESSION['kasir']) {
$sql=mysqli_query($koneksi,"SELECT * FROM tb_visi ");
$r=mysqli_fetch_array($sql);
echo " <div style='text-align:center; font-size:30px;'>
<div style='font-size:50px; font-family:impact;'>$r[judul]</div>
<hr>
<p>$r[isi]</p> </div>";
?> <?php
} else {
?><script>
            window.location.href = "?page=login";
        </script><?php
}
} else if(@$_GET['page'] == "logout"){
    include "inc/logout.php";
    } else if(@$_GET['page'] == "barang") {
    include "inc/barang.php";
    } else if(@$_GET['page'] == "pemasok") {
        include "inc/pemasok.php";
} else if(@$_GET['page'] == "pembelian") {
include "inc/pembelian.php";
} else if(@$_GET['page'] == "laporan_perbulan") {
include "inc/laporan_perbulan.php";
} else if(@$_GET['page'] == "laporan_perbulan_stok") {
include "inc/laporan_perbulan_stok.php";
} else if(@$_GET['page'] == "laporan_pertahun_stok") {
include "inc/laporan_pertahun_stok.php";
} else if(@$_GET['page'] == "laporan_perhari_stok") {
include "inc/laporan_perhari_stok.php";
} else if(@$_GET['page'] == "laporan_perhari") {
include "inc/laporan_perhari.php";
} else if(@$_GET['page'] == "laporan_pertahun") {
include "inc/laporan_pertahun.php";
} else if(@$_GET['page'] == "pimpinan") {
    include "inc/pimpinan.php";
} else if(@$_GET['page'] == "visi") {
include "inc/edit_visi.php";
} else if(@$_GET['page'] == "petugas") {
if(@$_SESSION['admin']) {
include "inc/petugas.php";
} else {
echo "Akses hanya untuk admin !";
}
} else if(@$_GET['page'] == "penjualan") {
include "inc/penjualan.php";
} else if(@$_GET['page'] == "struk") {
include "inc/struk.php";
} else if(@$_GET['page'] == "login") {
include "inc/login.php";
} else if(@$_GET['page'] == "akun") {
include "inc/akun.php";
} else if(@$_GET['page'] == "cetak_faktur") {
include "cetak_struk.php";
} ?>
</main>
<footer>
    &copy; Copyright 2016 - All Right Reserved
</footer>
</body>
</html>